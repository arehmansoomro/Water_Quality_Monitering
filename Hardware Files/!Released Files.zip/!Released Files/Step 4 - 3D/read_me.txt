Place following files here:

3D step file
3D pdf
